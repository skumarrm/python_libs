from .. import Provider as ProfileProvider  # pragma: no cover


class Provider(ProfileProvider):  # pragma: no cover
    pass
