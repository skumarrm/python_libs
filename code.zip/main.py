import json
from google.cloud import storage

def main(event, context):
    """Main entry point and event handler."""
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(event['bucket'])

    # Write config to destination path, overwriting any existing file
    dest_filename = f"Config/jumbo_bumbo.json"
    dest_blob = bucket.blob(dest_filename)

    print(f"Writing IDF config to {dest_filename}")
    dest_blob.upload_from_string(
        data=json.dumps({1:'Welcome'}, indent=4),
        content_type='application/json'
    )
